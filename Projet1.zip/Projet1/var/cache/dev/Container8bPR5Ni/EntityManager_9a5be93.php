<?php

namespace Container8bPR5Ni;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder5a36b = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer44798 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties2b357 = [
        
    ];

    public function getConnection()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getConnection', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getMetadataFactory', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getExpressionBuilder', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'beginTransaction', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getCache', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getCache();
    }

    public function transactional($func)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'transactional', array('func' => $func), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'wrapInTransaction', array('func' => $func), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'commit', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->commit();
    }

    public function rollback()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'rollback', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getClassMetadata', array('className' => $className), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'createQuery', array('dql' => $dql), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'createNamedQuery', array('name' => $name), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'createQueryBuilder', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'flush', array('entity' => $entity), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'clear', array('entityName' => $entityName), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->clear($entityName);
    }

    public function close()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'close', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->close();
    }

    public function persist($entity)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'persist', array('entity' => $entity), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'remove', array('entity' => $entity), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->remove($entity);
    }

    public function refresh($entity, ?int $lockMode = null)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'refresh', array('entity' => $entity, 'lockMode' => $lockMode), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->refresh($entity, $lockMode);
    }

    public function detach($entity)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'detach', array('entity' => $entity), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'merge', array('entity' => $entity), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getRepository', array('entityName' => $entityName), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'contains', array('entity' => $entity), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getEventManager', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getConfiguration', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'isOpen', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getUnitOfWork', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getProxyFactory', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'initializeObject', array('obj' => $obj), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'getFilters', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'isFiltersStateClean', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'hasFilters', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return $this->valueHolder5a36b->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer44798 = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, ?\Doctrine\Common\EventManager $eventManager = null)
    {
        static $reflection;

        if (! $this->valueHolder5a36b) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder5a36b = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder5a36b->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, '__get', ['name' => $name], $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        if (isset(self::$publicProperties2b357[$name])) {
            return $this->valueHolder5a36b->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5a36b;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder5a36b;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5a36b;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder5a36b;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, '__isset', array('name' => $name), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5a36b;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder5a36b;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, '__unset', array('name' => $name), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5a36b;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder5a36b;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, '__clone', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        $this->valueHolder5a36b = clone $this->valueHolder5a36b;
    }

    public function __sleep()
    {
        $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, '__sleep', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;

        return array('valueHolder5a36b');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer44798 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer44798;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer44798 && ($this->initializer44798->__invoke($valueHolder5a36b, $this, 'initializeProxy', array(), $this->initializer44798) || 1) && $this->valueHolder5a36b = $valueHolder5a36b;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder5a36b;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder5a36b;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
